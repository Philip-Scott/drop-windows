﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace notificationbar
{
    public partial class Form4 : Form
    {
        Form5 success = new Form5();

        public Form4()
        {
            InitializeComponent();
            timer1.Start();
            success.Visible = false;
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Increment(1);
            label1.Text = progressBar1.Value + " %";
            if (progressBar1.Value == 100)
            {
                success.Visible = true;
                Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 Principal = new Form2();
            Close();

        }
    }
}
