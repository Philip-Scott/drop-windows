﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace notificationbar
{
    public partial class Form1 : Form
    {
        Form notification = new Form2();

        public Form1()
        {
            InitializeComponent();     
          
            notification.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try {
                progressBar1.Increment(1);
                label1.Text = progressBar1.Value + " %";
                if (progressBar1.Value == 100)
                {
                    notification.Visible = true;
                    Close();
                }
            }
            catch(Exception a)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            Form2 Principal = new Form2();
            Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
     
    }
}
